﻿using MediatR;
using Application.UseCases.Queries;
using Domain.Repositories;
using Application.DTOs;
using AutoMapper;

namespace Application.UseCases.QueryHandlers
{
    public class GetAllBooksQueryHandler : IRequestHandler<GetAllBooksQuery, IEnumerable<BookDTO>>
    {
        private readonly IBookRepository repository;
        private readonly IMapper mapper;

        public GetAllBooksQueryHandler(IBookRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<IEnumerable<BookDTO>> Handle(GetAllBooksQuery request, CancellationToken cancellationToken)
        {
            var books = await repository.GetAllAsync();
            return mapper.Map<IEnumerable<BookDTO>>(books);
        }
    }

}
