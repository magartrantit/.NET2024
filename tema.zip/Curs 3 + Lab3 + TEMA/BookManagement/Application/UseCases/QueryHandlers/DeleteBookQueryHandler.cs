﻿using MediatR;
using Application.UseCases.Queries;
using Domain.Repositories;
using Application.DTOs;
using AutoMapper;

namespace Application.UseCases.QueryHandlers
{
    public class DeleteBookQueryHandler : IRequestHandler<DeleteBookQuery, BookDTO>
    {
        private readonly IBookRepository _bookRepository;
        private readonly IMapper _mapper;

        public DeleteBookQueryHandler(IBookRepository bookRepository, IMapper mapper)
        {
            _bookRepository = bookRepository;
            _mapper = mapper;
        }

        public async Task<BookDTO> Handle(DeleteBookQuery request, CancellationToken cancellationToken)
        {
            var book = await _bookRepository.GetByIdAsync(request.Id);
            if (book == null)
            {
                
                return null;
            }

            await _bookRepository.DeleteAsync(book.Id);

            return _mapper.Map<BookDTO>(book);
        }
    }
}
