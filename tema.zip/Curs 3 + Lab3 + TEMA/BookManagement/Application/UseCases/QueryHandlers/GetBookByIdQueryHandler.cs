﻿using MediatR;
using Application.UseCases.Queries;
using Domain.Repositories;
using Application.DTOs;
using AutoMapper;

namespace Application.UseCases.QueryHandlers
{
    public class GetBookByIdQueryHandler : IRequestHandler<GetBookByIdQuery, BookDTO>
    {
        public readonly IBookRepository repository;
        private readonly IMapper mapper;

        public GetBookByIdQueryHandler(IBookRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        

        public async Task<BookDTO> Handle(GetBookByIdQuery request, CancellationToken cancellationToken)
        {
            var book = await repository.GetByIdAsync(request.Id);
            //return new BookDTO
            //{
            //    Id = book.Id,
            //    Title = book.Title,
            //    Author = book.Author,
            //    ISBN = book.ISBN,
            //    PublicationDate = book.PublicationDate
            //};
            return mapper.Map<BookDTO>(book);

        }

    }
}
