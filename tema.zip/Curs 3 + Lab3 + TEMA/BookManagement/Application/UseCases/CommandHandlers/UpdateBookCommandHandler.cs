﻿using MediatR;

using Application.UseCases.Commands;

using Domain.Repositories;
using Domain.Entities;

namespace Application.UseCases.CommandHandlers
{
    public class UpdateBookCommandHandler : IRequestHandler<UpdateBookCommand, Guid>
    {
        private readonly IBookRepository repository;
        public UpdateBookCommandHandler(IBookRepository repository)
        {
            this.repository = repository;
        }


        public async Task<Guid> Handle(UpdateBookCommand request, CancellationToken cancellationToken)
        {
            var book = new Book
            {
                Id = request.Id,
                Title = request.Title,
                Author = request.Author,
                ISBN = request.ISBN,
                PublicationDate = request.PublicationDate
            };
            await repository.UpdateAsync(book);
            return book.Id;
        }
    }
    
}
