﻿using MediatR;
using Application.DTOs;

namespace Application.UseCases.Queries
{
    public class GetAllBooksQuery : IRequest<IEnumerable<BookDTO>>
    {
        public int Count { get; set; }

    }
}
