﻿using MediatR;
using Application.DTOs;

namespace Application.UseCases.Queries
{
    public class GetBookByIdQuery : IRequest<BookDTO>
    {
        public Guid Id { get; internal set; }
    }
}
