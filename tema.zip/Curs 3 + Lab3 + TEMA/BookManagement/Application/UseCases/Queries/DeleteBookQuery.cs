﻿using MediatR;
using Application.DTOs;


namespace Application.UseCases.Queries
{
    public class DeleteBookQuery : IRequest<BookDTO>
    {
        public Guid Id { get; set; }
    }
}
