﻿using Application.UseCases.Commands;
using Application.UseCases.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Application.DTOs;

namespace BookManagement.Controllers
{
    [Route("api/v1/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IMediator mediator;
        public BooksController(IMediator mediator)
        {
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookDTO>>> GetAllBooks([FromQuery] GetAllBooksQuery query)
        {
            var result = await mediator.Send(query);
            return Ok(result);
        }


        [HttpPost]
        public async Task<ActionResult<Guid>> CreateBook(CreateBookCommand command)
        {
            return await mediator.Send(command);
        }

        [HttpGet("{id:guid}")]
        public async Task<ActionResult<BookDTO>> GetBookById([FromQuery] GetBookByIdQuery query)
        {
            return await mediator.Send(query);
        }

        [HttpDelete("{id:guid}")]
        public async Task<ActionResult<BookDTO>> DeleteBook(Guid id)
        {
            var query = new DeleteBookQuery { Id = id };
            var result = await mediator.Send(query);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }

        [HttpPut("{id:guid}")]
        public async Task<ActionResult<BookDTO>> UpdateBook(Guid id, UpdateBookCommand command)
        {
            command.Id = id;
            var result = await mediator.Send(command);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }
    }
}